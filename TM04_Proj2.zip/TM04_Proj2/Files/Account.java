package Proj2.Files;

public abstract class Account {
	double interestRate;
	double amount;
	abstract double calculateInterest();
}
